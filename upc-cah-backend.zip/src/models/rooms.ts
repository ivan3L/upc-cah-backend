export interface roomModel {
    roomName: string;
    players: string[];
    namePlayer: string[]
}