export interface ICrudOperationsController{
    
}