const errorMessages = {
    notAuthorized: "Usted no tiene los permisos para realizar esta operación.",
    defaultError: "Ocurrió un error en el sistema, por favor inténtelo nuevamente."
}

export default errorMessages;